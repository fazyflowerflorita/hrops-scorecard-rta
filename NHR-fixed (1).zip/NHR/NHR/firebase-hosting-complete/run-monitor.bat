@echo off
REM HR Operations Scorecard - Auto Start Script
REM Just double-click this file to start monitoring!

echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║                                                                ║
echo ║   🚀 HR Operations Scorecard - Auto Monitor                   ║
echo ║                                                                ║
echo ║   Starting the data sync service...                           ║
echo ║                                                                ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ ERROR: Python is not installed or not in PATH
    echo.
    echo Please install Python from: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation
    echo.
    pause
    exit /b 1
)

echo ✅ Python found
echo.

REM Check if required packages are installed
echo 🔍 Checking required packages...
python -m pip show openpyxl >nul 2>&1
if errorlevel 1 (
    echo 📦 Installing openpyxl...
    python -m pip install openpyxl --quiet
)

python -m pip show firebase-admin >nul 2>&1
if errorlevel 1 (
    echo 📦 Installing firebase-admin...
    python -m pip install firebase-admin --quiet
)

echo ✅ All packages ready
echo.

REM Check if firebase-service-account.json exists
if not exist "firebase-service-account.json" (
    echo ❌ ERROR: firebase-service-account.json not found!
    echo.
    echo Make sure this file is in the same folder as this script:
    echo %cd%
    echo.
    pause
    exit /b 1
)

echo ✅ Firebase credentials found
echo.

REM Run the Python script
echo 🚀 Starting monitor service...
echo.
set /p SCORECARD_FOLDER=Paste the local Excel folder path: 
python folder-monitor-ENHANCED.py "%SCORECARD_FOLDER%"

REM If script exits, show error
if errorlevel 1 (
    echo.
    echo ❌ An error occurred
    pause
)
