#!/usr/bin/env python3
"""
HR Operations Scorecard - Enhanced Multi-File Parser
Handles all 37+ Excel files intelligently
Auto-syncs to Firebase
"""

import os
import sys
import time
from pathlib import Path
import openpyxl
import firebase_admin
from firebase_admin import credentials, db
from datetime import datetime
import hashlib
import json

FIREBASE_CONFIG = {
    "projectId": "hrops-scorecard---rta",
    "databaseURL": "https://hrops-scorecard---rta.firebaseio.com"
}


class EnhancedExcelParser:

    @staticmethod
    def read_excel(file_path):
        try:
            wb = openpyxl.load_workbook(file_path, data_only=True)
            ws = wb.active

            headers = []
            for cell in ws[1]:
                headers.append(str(cell.value).strip() if cell.value else '')

            data = []
            for row in ws.iter_rows(min_row=2, values_only=True):
                row_data = {}
                for idx, value in enumerate(row):
                    if idx < len(headers) and headers[idx]:
                        row_data[headers[idx]] = value
                if any(v is not None for v in row_data.values()):
                    data.append(row_data)

            wb.close()
            return data, headers
        except Exception as e:
            print(f"    ⚠ Could not read {file_path}: {e}")
            return [], []

    @staticmethod
    def normalize_key(key):
        """Lowercase, collapse whitespace/punctuation."""
        import re
        return re.sub(r'[^a-z0-9]+', ' ', str(key or '').lower()).strip()

    @staticmethod
    def get_value(row, *aliases):
        """Return the first non-empty value whose column name matches an alias."""
        normalized = {EnhancedExcelParser.normalize_key(k): v for k, v in row.items()}
        for alias in aliases:
            v = normalized.get(EnhancedExcelParser.normalize_key(alias))
            if v is not None and str(v).strip():
                return v
        return None

    @staticmethod
    def extract_employee_id(row):
        """Extract employee ID – looks for explicit ID columns first."""
        # Explicit column names
        v = EnhancedExcelParser.get_value(
            row,
            'Employee ID', 'Employee. ID', 'Emp ID', 'EmpID',
            'E. ID', 'Employee No', 'Emp No', 'Staff ID',
        )
        if v:
            candidate = str(v).strip().upper()
            if candidate:
                return candidate

        # Fallback: any column whose name contains 'emp' AND 'id'
        for key, value in row.items():
            k = EnhancedExcelParser.normalize_key(key)
            if 'emp' in k and 'id' in k and value:
                return str(value).strip().upper()

        # Last resort: a column literally named 'id' whose value looks like an emp ID
        for key, value in row.items():
            k = EnhancedExcelParser.normalize_key(key)
            if k == 'id' and value:
                val = str(value).strip().upper()
                if val and (val[0].isalpha() or val.isdigit()):
                    return val

        return None

    @staticmethod
    def extract_name(row):
        """Extract employee name."""
        v = EnhancedExcelParser.get_value(
            row,
            'Employee Name', 'Name', 'Names', 'Processor',
            'Associate', 'Staff Name', 'Full Name',
        )
        return str(v).strip() if v else None

    @staticmethod
    def extract_team(row):
        """Extract team name."""
        v = EnhancedExcelParser.get_value(
            row,
            'Team', 'Team Name', 'Process', 'Department',
            'Group', 'Unit',
        )
        return str(v).strip() if v else None

    @staticmethod
    def extract_manager(row):
        """Extract manager name."""
        v = EnhancedExcelParser.get_value(
            row,
            'Manager', 'Reporting Manager', 'India Reporting Manager',
            'Team Lead', 'Supervisor',
        )
        return str(v).strip() if v else None

    @staticmethod
    def extract_number(value):
        """Safe number extraction – handles %, commas, None."""
        if value is None or value == '':
            return 0
        if isinstance(value, (int, float)):
            return float(value)
        try:
            cleaned = str(value).strip().replace('%', '').replace(',', '')
            result = float(cleaned)
            return result if result == result else 0  # NaN guard
        except (ValueError, TypeError):
            return 0

    @staticmethod
    def get_number_by_key(row, *aliases):
        """Return the first non-zero number from columns matching any alias."""
        normalized = {EnhancedExcelParser.normalize_key(k): v for k, v in row.items()}
        for alias in aliases:
            nk = EnhancedExcelParser.normalize_key(alias)
            for col_key, col_val in normalized.items():
                if nk in col_key:
                    n = EnhancedExcelParser.extract_number(col_val)
                    if n:
                        return n
        return 0

    @staticmethod
    def latest_number(row, skip_keys=None):
        """Return the last non-zero number in the row, skipping ID/name columns."""
        skip_keys = skip_keys or set()
        skip_patterns = {'id', 'name', 'employee', 'emp', 'sheetname', 'manager', 'team', 'process'}
        latest = 0
        for key, value in row.items():
            k = EnhancedExcelParser.normalize_key(key)
            if k in skip_keys:
                continue
            if any(p in k for p in skip_patterns):
                continue
            n = EnhancedExcelParser.extract_number(value)
            if n:
                latest = n
        return latest

    @staticmethod
    def _store(result, emp_id, name, team, manager, **metrics):
        """Helper to upsert an employee entry in result dict."""
        if emp_id not in result:
            result[emp_id] = {}
        rec = result[emp_id]
        if name and not rec.get('name'):
            rec['name'] = name
        if team and not rec.get('team'):
            rec['team'] = team
        if manager and not rec.get('manager'):
            rec['manager'] = manager
        for k, v in metrics.items():
            if v:
                rec[k] = v

    @staticmethod
    def parse_file(file_path, team_hint=''):
        """Intelligently parse a file based on its name and content."""
        file_name = Path(file_path).name.lower()
        data, headers = EnhancedExcelParser.read_excel(file_path)

        if not data:
            return {}

        result = {}

        for row in data:
            emp_id = EnhancedExcelParser.extract_employee_id(row)
            if not emp_id:
                continue

            name    = EnhancedExcelParser.extract_name(row)
            team    = EnhancedExcelParser.extract_team(row) or team_hint
            manager = EnhancedExcelParser.extract_manager(row)

            # ── ATTENDANCE ────────────────────────────────────────────────
            if 'attendance' in file_name:
                attendance = (
                    EnhancedExcelParser.get_number_by_key(
                        row, 'attendance %', '% attendance', 'attendance', 'present %', 'present'
                    )
                    or EnhancedExcelParser.latest_number(row)
                )
                EnhancedExcelParser._store(result, emp_id, name, team, manager, attendance=attendance)

            # ── PROCESS KNOWLEDGE ─────────────────────────────────────────
            elif 'knowledge' in file_name:
                score = (
                    EnhancedExcelParser.get_number_by_key(row, 'score', 'test score', 'marks', 'knowledge')
                    or EnhancedExcelParser.latest_number(row)
                )
                EnhancedExcelParser._store(result, emp_id, name, team, manager, process_knowledge=score)

            # ── PRODUCTION / PRODUCTIVITY ─────────────────────────────────
            elif 'production' in file_name or 'productivity' in file_name:
                productivity = (
                    EnhancedExcelParser.get_number_by_key(
                        row, 'count', 'completed', 'cases', 'production', 'units', 'total count'
                    )
                    or EnhancedExcelParser.latest_number(row)
                )
                EnhancedExcelParser._store(result, emp_id, name, team, manager, productivity=productivity)

            # ── AUDIT / QMG / ERROR TRACKER ───────────────────────────────
            elif any(x in file_name for x in ('audit', 'qmg error', 'error tracker')):
                audit_score = EnhancedExcelParser.get_number_by_key(row, 'score', 'rating', 'quality score')
                audit_errors = EnhancedExcelParser.get_number_by_key(row, 'error', 'errors', 'finding', 'count')
                EnhancedExcelParser._store(
                    result, emp_id, name, team, manager,
                    audit_score=audit_score, audit_errors=audit_errors
                )

            # ── NH / BG PENDING ───────────────────────────────────────────
            elif 'nh pending' in file_name or 'bg pending' in file_name:
                pending = (
                    EnhancedExcelParser.get_number_by_key(row, 'pending', 'count')
                    or EnhancedExcelParser.latest_number(row)
                )
                EnhancedExcelParser._store(result, emp_id, name, team, manager, nh_pending=pending)

            # ── PAPERWORK ─────────────────────────────────────────────────
            elif 'paperwork' in file_name:
                pw = (
                    EnhancedExcelParser.get_number_by_key(row, 'count', 'pending', 'allocated')
                    or EnhancedExcelParser.latest_number(row)
                )
                EnhancedExcelParser._store(result, emp_id, name, team, manager, paperwork=pw)

            # ── TERMINATION ───────────────────────────────────────────────
            elif 'termination' in file_name:
                EnhancedExcelParser._store(result, emp_id, name, team, manager, status='Terminated')

            # ── DATA CHANGES ──────────────────────────────────────────────
            elif 'data changes' in file_name or 'changes tracker' in file_name:
                changes = (
                    EnhancedExcelParser.get_number_by_key(row, 'change', 'count')
                    or EnhancedExcelParser.latest_number(row)
                )
                EnhancedExcelParser._store(result, emp_id, name, team, manager, data_changes=changes)

            # ── GENERIC MASTER / SCORECARD FILE ──────────────────────────
            else:
                metrics = {}
                overall = EnhancedExcelParser.get_number_by_key(row, 'overall score', 'overall_score', 'score')
                if overall:
                    metrics['overall_score'] = overall
                att = EnhancedExcelParser.get_number_by_key(row, 'attendance')
                if att:
                    metrics['attendance'] = att
                know = EnhancedExcelParser.get_number_by_key(row, 'process knowledge', 'knowledge')
                if know:
                    metrics['process_knowledge'] = know
                prod = EnhancedExcelParser.get_number_by_key(row, 'productivity', 'production')
                if prod:
                    metrics['productivity'] = prod
                EnhancedExcelParser._store(result, emp_id, name, team, manager, **metrics)

        return result


class DataConsolidator:

    @staticmethod
    def consolidate(all_file_data):
        """Merge all file data into unified employee records."""
        consolidated = {}

        for file_data in all_file_data:
            for emp_id, metrics in file_data.items():
                if emp_id not in consolidated:
                    consolidated[emp_id] = {
                        'empId': emp_id,
                        'lastUpdated': datetime.now().isoformat()
                    }
                rec = consolidated[emp_id]
                for k, v in metrics.items():
                    # Don't overwrite name/team/manager once set
                    if k in ('name', 'team', 'manager') and rec.get(k):
                        continue
                    rec[k] = v

        return consolidated


class FirebaseSync:

    @staticmethod
    def initialize():
        try:
            if firebase_admin._apps:
                firebase_admin.delete_app(firebase_admin.get_app())

            cred = credentials.Certificate('firebase-service-account.json')
            firebase_admin.initialize_app(cred, {
                'databaseURL': FIREBASE_CONFIG['databaseURL']
            })
            return True
        except Exception as e:
            print(f"❌ Firebase error: {e}")
            return False

    @staticmethod
    def sync_data(consolidated_data):
        try:
            now = datetime.now().isoformat()
            employee_master = {}
            performance_data = {}

            for emp_id, record in consolidated_data.items():
                name        = record.get('name') or emp_id
                team        = record.get('team') or 'Unassigned'
                manager     = record.get('manager') or ''
                attendance  = EnhancedExcelParser.extract_number(record.get('attendance'))
                knowledge   = EnhancedExcelParser.extract_number(record.get('process_knowledge'))
                productivity= EnhancedExcelParser.extract_number(record.get('productivity'))
                audit_score = EnhancedExcelParser.extract_number(record.get('audit_score'))

                score_inputs = [v for v in [attendance, knowledge, audit_score] if v > 0]
                overall_score = round(sum(score_inputs) / len(score_inputs), 2) if score_inputs else 0

                employee_master[emp_id] = {
                    'empId':      emp_id,
                    'name':       name,
                    'team':       team,
                    'manager':    manager,
                    'department': record.get('department', 'HR Operations'),
                    'lastUpdated': now,
                }

                performance_data[emp_id] = {
                    **{k: v for k, v in record.items() if k not in ('lastUpdated',)},
                    'empId':           emp_id,
                    'name':            name,
                    'team':            team,
                    'manager':         manager,
                    'attendance':      attendance,
                    'process_knowledge': knowledge,
                    'productivity':    productivity,
                    'audit_score':     audit_score,
                    'overall_score':   overall_score,
                    'lastUpdated':     now,
                }

            # ── RANK CALCULATION ─────────────────────────────────────────
            sorted_ids = sorted(
                performance_data.keys(),
                key=lambda eid: performance_data[eid].get('overall_score', 0),
                reverse=True
            )
            for rank, eid in enumerate(sorted_ids, 1):
                performance_data[eid]['rank'] = rank
                employee_master[eid]['rank']  = rank

            db.reference('/').update({
                'employee-master':    employee_master,
                'performance-data':   performance_data,
                'sync-status': {
                    'lastUpdated':   now,
                    'employeeCount': len(performance_data),
                },
            })
            return True
        except Exception as e:
            print(f"❌ Sync error: {e}")
            return False


class FolderMonitor:

    def __init__(self, folder_path):
        self.folder_path = Path(folder_path)
        self.file_hashes = {}
        self.last_sync   = None

    def get_file_hash(self, file_path):
        try:
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception:
            return None

    def find_excel_files(self):
        """Find all Excel files recursively, returning (path, team_hint) pairs."""
        files = []
        for f in self.folder_path.rglob('*.xlsx'):
            if not f.name.startswith('~$'):
                # Use immediate parent folder name as team hint when in a subfolder
                team_hint = f.parent.name if f.parent != self.folder_path else ''
                files.append((f, team_hint))
        return files

    def process_files(self):
        excel_files = self.find_excel_files()

        if not excel_files:
            print("  No Excel files found.")
            return False

        print(f"\n📁 Found {len(excel_files)} Excel files")

        # Detect any changed file; if so, reparse everything for a full snapshot
        any_changed = False
        for file_path, _ in excel_files:
            current_hash = self.get_file_hash(file_path)
            file_key = str(file_path)
            if file_key not in self.file_hashes or self.file_hashes[file_key] != current_hash:
                self.file_hashes[file_key] = current_hash
                any_changed = True

        if not any_changed:
            print("  No changes detected.")
            return False

        all_data   = []
        file_count = 0

        for file_path, team_hint in excel_files:
            print(f"  Processing: {file_path.name}" + (f" (team: {team_hint})" if team_hint else ''))
            file_data = EnhancedExcelParser.parse_file(str(file_path), team_hint)
            if file_data:
                all_data.append(file_data)
                file_count += 1

        if not all_data:
            print("  ⚠ No employee data extracted.")
            return False

        print(f"\n🔗 Consolidating data from {file_count} files...")
        consolidated = DataConsolidator.consolidate(all_data)

        print(f"☁️  Syncing {len(consolidated)} employees to Firebase...")
        if FirebaseSync.sync_data(consolidated):
            self.last_sync = datetime.now()
            print(f"✅ Sync complete – {self.last_sync.strftime('%Y-%m-%d %H:%M:%S')}")
            return True

        return False

    def start(self, interval=30):
        print("\n╔════════════════════════════════════════════════════════════════╗")
        print("║   HR OPERATIONS SCORECARD - Multi-File Monitor                ║")
        print("╚════════════════════════════════════════════════════════════════╝\n")
        print(f"📁 Monitoring: {self.folder_path}")
        print(f"⏱  Checking every {interval} seconds (recursive scan)")
        print("Press Ctrl+C to stop...\n")

        try:
            iteration = 0
            while True:
                iteration += 1
                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Check #{iteration}")
                self.process_files()
                time.sleep(interval)
        except KeyboardInterrupt:
            print("\n\n✅ Monitor stopped.")


def main():
    print("\nEnter your local folder path:")
    print("Example: C:\\Users\\YourName\\Pride Technologies\\RTA - 2026\n")

    folder_path = (
        sys.argv[1].strip().strip('"')
        if len(sys.argv) > 1
        else input("Folder path: ").strip().strip('"')
    )

    if not folder_path or not Path(folder_path).exists():
        print("❌ Folder not found!")
        return

    print("\n🔄 Initializing Firebase...")
    if not FirebaseSync.initialize():
        print("❌ Firebase initialization failed!")
        return

    print("✅ Firebase connected!")
    monitor = FolderMonitor(folder_path)
    monitor.start(interval=30)


if __name__ == "__main__":
    main()
